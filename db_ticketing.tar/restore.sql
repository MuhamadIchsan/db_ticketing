--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP TABLE public.tb_type_tranportasi;
DROP TABLE public.tb_transportasi;
DROP TABLE public.tb_rute;
DROP TABLE public.tb_petugas;
DROP TABLE public.tb_penumpang;
DROP TABLE public.tb_pemesanan;
DROP TABLE public.tb_level;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level character varying(20) NOT NULL,
    nama_level character varying(20) NOT NULL
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_pemesanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pemesanan (
    id_pemesanan character varying(20) NOT NULL,
    kode_pemesanan character varying(20) NOT NULL,
    tanggal_pemesanan date NOT NULL,
    tempat_pemesanan character varying(20) NOT NULL,
    id_pelanggan character varying(20) NOT NULL,
    kode_kursi character varying(20) NOT NULL,
    id_rute character varying(20) NOT NULL,
    tujuan character varying(20) NOT NULL,
    tanggal_berangkat date NOT NULL,
    jam_cekin time without time zone NOT NULL,
    jam_berangkat time without time zone NOT NULL,
    total_bayar integer NOT NULL,
    id_petugas character varying(20) NOT NULL
);


ALTER TABLE tb_pemesanan OWNER TO postgres;

--
-- Name: tb_penumpang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_penumpang (
    id_penumpang character varying(20) NOT NULL,
    usernames character varying(100) NOT NULL,
    passwords character varying(100) NOT NULL,
    nama_penumpang character varying(100) NOT NULL,
    alamat_penumpang text NOT NULL,
    tanggal_lahir date NOT NULL,
    jenis_kelamin character varying(20) NOT NULL,
    telepon character varying(15) NOT NULL
);


ALTER TABLE tb_penumpang OWNER TO postgres;

--
-- Name: tb_petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_petugas (
    id_petugas character varying(20) NOT NULL,
    usernames character varying(20) NOT NULL,
    passwords character varying(20) NOT NULL,
    nama_petugas character varying(20) NOT NULL,
    id_level character varying(20) NOT NULL
);


ALTER TABLE tb_petugas OWNER TO postgres;

--
-- Name: tb_rute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_rute (
    id_rute character varying(20) NOT NULL,
    tujuan text NOT NULL,
    rute_awal text NOT NULL,
    rute_akhir text NOT NULL,
    harga integer NOT NULL,
    id_transportasi character varying(20) NOT NULL
);


ALTER TABLE tb_rute OWNER TO postgres;

--
-- Name: tb_transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_transportasi (
    id_transportasi character varying(20) NOT NULL,
    kode character varying(50) NOT NULL,
    jumlah_kursi integer NOT NULL,
    keterangan character varying(100),
    id_type_transportasi character varying(20)
);


ALTER TABLE tb_transportasi OWNER TO postgres;

--
-- Name: tb_type_tranportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_type_tranportasi (
    id_type_tranportasi character varying(20) NOT NULL,
    nama_type character varying(100) NOT NULL,
    keterangan character varying(20) NOT NULL
);


ALTER TABLE tb_type_tranportasi OWNER TO postgres;

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2818.dat';

--
-- Data for Name: tb_pemesanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM stdin;
\.
COPY tb_pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM '$$PATH$$/2819.dat';

--
-- Data for Name: tb_penumpang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_penumpang (id_penumpang, usernames, passwords, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telepon) FROM stdin;
\.
COPY tb_penumpang (id_penumpang, usernames, passwords, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telepon) FROM '$$PATH$$/2815.dat';

--
-- Data for Name: tb_petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_petugas (id_petugas, usernames, passwords, nama_petugas, id_level) FROM stdin;
\.
COPY tb_petugas (id_petugas, usernames, passwords, nama_petugas, id_level) FROM '$$PATH$$/2816.dat';

--
-- Data for Name: tb_rute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM stdin;
\.
COPY tb_rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM '$$PATH$$/2817.dat';

--
-- Data for Name: tb_transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_type_transportasi) FROM stdin;
\.
COPY tb_transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_type_transportasi) FROM '$$PATH$$/2820.dat';

--
-- Data for Name: tb_type_tranportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_type_tranportasi (id_type_tranportasi, nama_type, keterangan) FROM stdin;
\.
COPY tb_type_tranportasi (id_type_tranportasi, nama_type, keterangan) FROM '$$PATH$$/2821.dat';

--
-- PostgreSQL database dump complete
--

